package com.github.maulazaro;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SnapstoryApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
