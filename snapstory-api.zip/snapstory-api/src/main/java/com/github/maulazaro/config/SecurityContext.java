package com.github.maulazaro.config;

public class SecurityContext {
    public static final String JWT_KEY="vopejfdltkvledpfmvkisdqgjvobtksofdsifpeomfspfksdfsdfss";
    public static final String HEADER="Authorization";
}
