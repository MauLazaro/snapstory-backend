package com.github.maulazaro.exception;

public class CommentException extends Exception {
    public CommentException(String message) {
        super(message);
    }
}
