package com.github.maulazaro.exception;

public class PostException extends Exception {

    public PostException(String message) {
        super(message);
    }
}
