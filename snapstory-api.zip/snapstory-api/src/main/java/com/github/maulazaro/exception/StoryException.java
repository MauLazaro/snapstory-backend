package com.github.maulazaro.exception;

public class StoryException extends Exception {

    public StoryException(String message) {
        super(message);
    }
}
